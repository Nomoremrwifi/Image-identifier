Just Drag and drop the index.html 
> wait the camera pop up prompt 
> click Allow
> download any image of Cat, Dog, snake using your phone
> show the image of the Cat using your phone via camera then click (Add cat)etc..
> once the image are set and good to go

